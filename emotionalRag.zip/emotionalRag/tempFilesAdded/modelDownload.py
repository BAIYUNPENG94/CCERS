from transformers import AutoTokenizer, AutoModelForCausalLM

#model_id = "BAAI/bge-base-zh-v1.5"
#my_model_path = "/home/jarvis/Workspace/emoRag/emotionalRag/localModels"
#
## 下载并缓存到本地（默认 ~/.cache/huggingface）
#tokenizer = AutoTokenizer.from_pretrained(model_id, cache_dir=my_model_path, trust_remote_code=True)
#model = AutoModelForCausalLM.from_pretrained(model_id, cache_dir=my_model_path, trust_remote_code=True)
#
#print("Model Download over" + model_id)

model_id2 = "Qwen/Qwen2-7B-Instruct"
my_model_path = "/home/jarvis/Workspace/emoRag/emotionalRag/localModels"

tokenizer2 = AutoTokenizer.from_pretrained(model_id2, cache_dir=my_model_path, trust_remote_code=True)
model2 = AutoModelForCausalLM.from_pretrained(model_id2, cache_dir=my_model_path, trust_remote_code=True)

print("Model Download over" + model_id2)