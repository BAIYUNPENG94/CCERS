OPENAI_API_BASE = "curl https://api.openai.com/v1/models"
MODEL_NAME = "XXXXXXXXXX"
OPENAI_API_KEY = "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"

Qwen_PATH = "/home/jarvis/Workspace/emoRag/emotionalRag/localModels/models--Qwen--Qwen2-7B-Instruct/snapshots/f2826a00ceef68f0f2b946d945ecc0477ce4450c"
ChatGLM_PATH = "XXXXXXXXXX"
BGEModel_PATH = "/home/jarvis/Workspace/emoRag/emotionalRag/localModels/models--BAAI--bge-base-zh-v1.5/snapshots/f03589ceff5aac7111bd60cfc7d497ca17ecac65"

CharacterLLM_DATA_PATH = "XXXXXXXXXX"
